﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace WC.Web
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/myscripts").Include(
                    "~/js/jquery.min.js",
                    "~/js/jquery.easing-1.3.min.js",
                    "~/js/jquery.queryloader2.min.js",
                    "~/js/smoothscroll.js",
                    "~/js/waypoints.min.js",
                    "~/js/jquery.transit.min.js",
                    "~/js/jquery.scrollTo.min.js",
                    "~/js/jquery.small.plugins.js",
                    "~/js/owl.carousel.min.js",
                    "~/js/jquery.fancybox-1.3.4.pack.js",
                    "~/js/retina.min.js",
                    "~/js/custom.js"));  


            BundleTable.EnableOptimizations = false;

            //bundles.Add(new StyleBundle("~/Content/css").Include(
            //          "~/Content/bootstrap.css",
            //          "~/Content/site.css"));
        }
    }
}