﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using WC.Web.Models;
using System.IO;

namespace WC.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = StaticContent.HomeTitle + StaticContent.TitleSeperator + StaticContent.BaseTitle;
            var menu = StaticContent.Menu;
            ViewBag.Menu = menu;
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Title = StaticContent.AboutTitle + StaticContent.TitleSeperator + StaticContent.BaseTitle;
            var menu = StaticContent.Menu;
            ViewBag.Menu = menu;
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Title = StaticContent.ContactTitle + StaticContent.TitleSeperator + StaticContent.BaseTitle;
            var menu = StaticContent.Menu;
            ViewBag.Menu = menu;

            ViewBag.ContactPhoneNumber = StaticContent.ContactPhoneNo;
            return View();
        }

        [HttpPost]
        public JsonResult SaveContact(Contact contactObj)
        {
            try
            {
                var csv = new StringBuilder();

                var newLine = string.Format("{0},{1},{2},{3},{4}", contactObj.Name, contactObj.Email, contactObj.Phone, contactObj.Subject, contactObj.Message);
                csv.AppendLine(newLine);

                //after your loop
                var filePath = DateTime.Now.Day + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + ".csv";
                System.IO.File.WriteAllText(Server.MapPath("~/ContactData/" + filePath), csv.ToString());
                return Json("true");
            }
            catch (Exception ex)
            {
                return Json("Sorry! Error occurred. " + ex.Message);
            }
        }


        public string GetFile(string date, string passcode)
        {
            string url = "Invalid request!";
            if (passcode == StaticContent.PassCode)
            {
                var address = string.Format("{0}://{1}", Request.Url.Scheme, Request.Url.Authority);

                url = "<a href='" + address + "/ContactData/" + date + ".csv" + "'/>click here to download</a>";
            }
            return url;
        }

        public ActionResult Portfolio()
        {
            ViewBag.Title = StaticContent.Portfolio + StaticContent.TitleSeperator + StaticContent.BaseTitle;
            var menu = StaticContent.Menu;
            ViewBag.Menu = menu;
            return View();
        }
    }
}
