﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WC.Web.Models;

namespace WC.Web.Controllers
{
    public class WorkController : Controller
    {
        //
        // GET: /Work/

        public ActionResult Category(string c)
        {
            var menu = StaticContent.Menu;
            ViewBag.Menu = menu;

            if (!string.IsNullOrEmpty(c))
            {
                if (c.ToLower() == StaticContent.WeddingCategory.PreWedding.ToString().ToLower())
                {
                    ViewBag.Title = StaticContent.PreWedding + StaticContent.TitleSeperator + StaticContent.BaseTitle;
                    ViewBag.Header = StaticContent.PreWeddingHeader;
                    ViewBag.Description = StaticContent.PreWeddingDescription;
                    return View("Index", GetFiles(StaticContent.PreWeddingImagePath));
                }
                else if (c.ToLower() == StaticContent.WeddingCategory.Candid.ToString().ToLower())
                {
                    ViewBag.Title = StaticContent.Candid + StaticContent.TitleSeperator + StaticContent.BaseTitle;
                    ViewBag.Header = StaticContent.CandidHeader;
                    ViewBag.Description = StaticContent.CandidDescription;
                    return View("Index", GetFiles(StaticContent.CandidImagePath));
                }
                else
                {
                    // default
                    return RedirectToAction("index", "home");
                }
            }
            else
            {
                // default
                return RedirectToAction("index", "home");
            }
        }


        private List<Slider> GetFiles(string path)
        {
            string[] filePaths = Directory.GetFiles(Server.MapPath("~/" + path));

            List<Slider> files = new List<Slider>();
            foreach (string filePath in filePaths)
            {
                string fileName = Path.GetFileName(filePath);
                files.Add(new Slider
                {
                    title = fileName.Split('.')[0].ToString(),
                    src = "../" + path + fileName
                });
            }
            return files;
        }
    }
}
