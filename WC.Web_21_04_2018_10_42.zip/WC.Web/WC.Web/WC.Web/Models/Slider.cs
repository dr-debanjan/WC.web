﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WC.Web.Models
{
    public class Slider
    {
        public string src { get; set; }
        public string title { get; set; }
    }
}