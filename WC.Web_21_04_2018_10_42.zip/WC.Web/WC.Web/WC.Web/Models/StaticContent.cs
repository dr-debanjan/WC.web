﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace WC.Web.Models
{
    public class StaticContent
    {
        public static string BaseTitle = ConfigurationManager.AppSettings["BaseTitle"];

        public static string HomeTitle = "Home";
        public static string AboutTitle = "About";
        public static string ContactTitle = "Contact";
        public static string Portfolio = "Portfolio";

        

        public static string TitleSeperator = " | ";

        public static List<List<string>> Menu = new List<List<string>>() 
        {
            new List<string>(){"Home", "/home/index", ""}, 
            new List<string>(){"About", "/home/about", ""}, 
            new List<string>(){"Portfolio", "/home/Portfolio", ""},
            new List<string>(){"Fun at work", "/fun-at-work", ""},
            new List<string>(){"Contact", "/home/Contact", ""}
        };

        public static List<List<string>> ContactPhoneNo = new List<List<string>>()
        {
            new List<string>(){"General", "99999999"}, 
            new List<string>(){"Home1", "99999999"}, 
            new List<string>(){"Home2", "99999999"}, 
            new List<string>(){"Home3", "99999999"}
        };

        public static string PassCode = ConfigurationManager.AppSettings["PassCode"];


        public enum WeddingCategory {
            PreWedding,
            Candid,
            HoneyMoon,
            WeTwo
        }

        

        #region page title 
        public static string PreWedding = "Pre Wedding";
        public static string Candid = "Candid & creative wedding photography";
        #endregion

        #region page header
        public static string PreWeddingHeader = "Prewedding photoshoot";
        public static string CandidHeader = "Candid & creative wedding photography";
        #endregion


        #region page description
        public static string PreWeddingDescription = "Explore our latest Prewedding clicks.";
        public static string CandidDescription = "Explore our latest Candid & creative wedding photography";
        #endregion

        #region page image path 
        public static string PreWeddingImagePath = "img/wedding/pre/";
        public static string CandidImagePath = "img/wedding/candid/";
        #endregion
    }
}